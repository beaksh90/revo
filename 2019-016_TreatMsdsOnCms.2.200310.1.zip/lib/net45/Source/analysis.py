import os, sys, getopt
import codecs, re
import win32com.client

import CONSTANTS as CONST
import config as conf
import common as comm

from comm import excel as exl

def getFiles(folder):
    files = []

    try:
        fs = os.listdir(folder)

        for f in fs:
            file, ext = os.path.splitext(f)

            if ext == '.txt':
                filepath = os.path.join(folder, f)
                files.append(filepath)
    except Exception as e:
        raise e
    finally:
        pass

    return files

def readFile(filepath):

    try:
        fp = codecs.open(filepath, 'r', encoding='utf8')

        lines = fp.readlines()

    except Exception as e:
        raise e
    finally:
        fp.close()

    return lines

def loadPictogramData():
    try:
        xl, wb, ws = exl.openWorkbook(conf.path_master, conf.sheet_name_pictogram)

        lastrow, lastcol = exl.getCounts(ws, 1, 1)
        
        data = {}

        for i in range(2, lastrow + 1):
            ghcode = ws.Cells(i, 1).Value
            desc = ws.Cells(i, 2).Value
            hcodes = ws.Cells(i, 3).Value

            if hcodes:
                hcodes = hcodes.split(',')

            for hcode in hcodes:

                if not hcode in data:
                    data[hcode] = []
                
                ghcodes = data[hcode]

                if not ghcode in ghcodes:
                    ghcodes.append(ghcode)
    except Exception as e:
        raise e
    finally:
        wb.Close()

    return data

def initColumns(xl, ws, columns, markings):
    try:
        lastColname = exl.getColumnName(ws, len(columns))
        cells = ws.Columns('A:%s' %(lastColname))
        cells.ClearContents()
        cells.Interior.ColorIndex = win32com.client.constants.xlNone

        colummIndex = 1

        for column in columns:
            ws.Cells(1, colummIndex).Value = column
            if column in markings:
                colname = exl.getColumnName(ws, colummIndex)
                ws.Columns('%s:%s' % (colname, colname)).Interior.ColorIndex = CONST.COLOR_INDEX_EXCEL_ORANGE

            colummIndex += 1

        ws.Cells(1, 1).AutoFilter(1)

        ws.Cells(2, 2).Select()
        xl.ActiveWindow.FreezePanes = True

    except Exception as e:
        raise e
    finally:
        pass

def getAnalysis(company):
    try:
        anal = None
        
        if company in CONST.COMPANY_NAMES_SIGMAALDRICH:
            from anals.analysis_sigmaaldrich import Analysis as Anal
            anal = Anal(CONST.COLUMNS)
            company = CONST.COMPANY_NAMES_SIGMAALDRICH[0]
        elif company in CONST.COMPANY_NAMES_COMBIBLOCKS:
            from anals.analysis_combiblocks import Analysis as Anal
            anal = Anal(CONST.COLUMNS)
            company = CONST.COMPANY_NAMES_COMBIBLOCKS[0]
        elif company in CONST.COMPANY_NAMES_DAEJUNGHWAGEUM:
            from anals.analysis_daejunghwageum import Analysis as Anal
            anal = Anal(CONST.COLUMNS)
            company = CONST.COMPANY_NAMES_DAEJUNGHWAGEUM[0]
        elif company in CONST.COMPANY_NAMES_TCI:
            from anals.analysis_tci import Analysis as Anal
            anal = Anal(CONST.COLUMNS)
            company = CONST.COMPANY_NAMES_TCI[0]
        elif company in CONST.COMPANY_NAMES_ALFAAESAR:
            from anals.analysis_alfaaesar import Analysis as Anal
            anal = Anal(CONST.COLUMNS)
            company = CONST.COMPANY_NAMES_ALFAAESAR[0]
        elif company in CONST.COMPANY_NAMES_CAYMANCHEMICAL:
            from anals.analysis_caymanchemical import Analysis as Anal
            anal = Anal(CONST.COLUMNS)
            company = CONST.COMPANY_NAMES_CAYMANCHEMICAL[0]
        elif company in CONST.COMPANY_NAMES_DUCHEFABIOCHEMIE:
            from anals.analysis_duchefabiochemie import Analysis as Anal
            anal = Anal(CONST.COLUMNS)
            company = CONST.COMPANY_NAMES_DUCHEFABIOCHEMIE[0]
        else:
            from anals.analysis_common import Analysis as Anal
            anal = Anal(CONST.COLUMNS)

    except Exception as e:
        raise e
    finally:
        pass

    return anal, company

def analysis(isFolder, company, files):
    
    try:
        xl = None
        wb = None
        ws = None
        result = None

        if not isFolder:
            file = files[0]
            filepath = '%s.xlsx' % os.path.splitext(file)[0]
        else:
            filepath = conf.path_analysis

        anal, company = getAnalysis(company)

        xl, wb, ws = exl.openWorkbook(filepath, company, True, False)

        initColumns(xl, ws, CONST.COLUMNS, CONST.MARKINGS)

        pictogramData = loadPictogramData()

        row = 2

        for file in files:

            try:
                column = 1
                filename = os.path.basename(file)
                # ws.Cells(row, column).Select()
                ws.Cells(row, column).Value = filename

                lines = readFile(file)
                
                lang, matchedContents, missmatched = anal.matchContents(lines)
                # ws.Cells(row, 4).Value = '\n'.join(matchedContents['8.노출방지및개인보호구'])
                column += 1
                ws.Cells(row, column).Value = lang

                column += 1
                if len(missmatched) == 0:
                    ws.Cells(row, column).Value = '일치'
                
                column += 1
                ws.Cells(row, column).Value = ','.join(missmatched)

                if len(missmatched) == 0:
                    date, sentence, lines = anal.matchRevisionDate(anal.getRevisionDateContent())
                    column += 1
                    ws.Cells(row, column).Value = '\n'.join(lines)
                    comm.gLogger.info('%s %s' % (date, sentence))
                    column += 1
                    ws.Cells(row, column).Value = sentence
                    column += 1
                    ws.Cells(row, column).Value = date

                    # column += 1
                    # contents = matchedContents['2.유해성위험성']
                    # contents = '\n'.join(contents)
                    # ws.Cells(row, column).Value = contents
                    signal, sentence, lines = anal.matchSignal(anal.getSignalContent())
                    comm.gLogger.info('%s %s' % (signal, sentence))
                    column += 1
                    ws.Cells(row, column).Value = '\n'.join(lines)
                    column += 1
                    ws.Cells(row, column).Value = sentence
                    column += 1
                    ws.Cells(row, column).Value = signal
                    
                    hcodes, pcodes = anal.matchCodes(lines)
                    comm.gLogger.info(hcodes)
                    comm.gLogger.info(pcodes)
                    column += 1
                    ws.Cells(row, column).Value = '\n'.join(hcodes)
                    column += 1
                    ws.Cells(row, column).Value = '\n'.join(pcodes)
                    
                    pictograms, regression = anal.matchPictogram(hcodes, pictogramData)
                    comm.gLogger.info(pictograms)
                    comm.gLogger.info(regression)
                    column += 1
                    ws.Cells(row, column).Value = '\n'.join(pictograms)
                    column += 1
                    ws.Cells(row, column).Value = '\n'.join(regression)
                    
                    # column += 1
                    # contents = matchedContents['3.구성성분의명칭및함유량']
                    # contents = '\n'.join(contents)
                    # ws.Cells(row, column).Value = contents
                    # composition, casInfos, regression, sentence, lines = anal.matchCAS(anal.getCASContent())
                    casInfos, lines = anal.matchCAS(anal.getCASContent())
                    comm.gLogger.info(casInfos)
                    column += 1
                    ws.Cells(row, column).Value = '\n'.join(lines)
                    column += 1
                    ws.Cells(row, column).Value = '\n'.join(casInfos)
                    composition, regression, sentence, lines = anal.matchSubstance(anal.getCASContent(), casInfos)
                    comm.gLogger.info(sentence)
                    comm.gLogger.info(composition)
                    comm.gLogger.info(regression)
                    column += 1
                    ws.Cells(row, column).Value = sentence
                    column += 1
                    ws.Cells(row, column).Value = composition
                    column += 1
                    ws.Cells(row, column).Value = regression
                    
                    # column += 1
                    # contents = matchedContents['7.취급및저장방법']
                    # contents = '\n'.join(contents)
                    # ws.Cells(row, column).Value = contents
                    handling, temperatureLine, temperature, lines = anal.matchHandling(anal.getHandlingContent())
                    # comm.gLogger.info(temperatureLine)
                    # comm.gLogger.info(temperature)
                    comm.gLogger.info(handling)
                    column += 1
                    ws.Cells(row, column).Value = '\n'.join(lines)
                    column += 1
                    ws.Cells(row, column).Value = '\n'.join(temperatureLine)
                    column += 1
                    ws.Cells(row, column).Value = temperature
                    column += 1
                    ws.Cells(row, column).Value = handling
                    
                    # column += 1
                    # contents = matchedContents['9.물리화학적특정']
                    # contents = '\n'.join(contents)
                    # ws.Cells(row, column).Value = contents
                    form, sentence, lines = anal.matchForm(anal.getFormContent())
                    comm.gLogger.info(sentence)
                    comm.gLogger.info(form)
                    column += 1
                    ws.Cells(row, column).Value = '\n'.join(lines)
                    column += 1
                    ws.Cells(row, column).Value = sentence
                    column += 1
                    ws.Cells(row, column).Value = form

                    dangerous, sentence, lines = anal.matchRegulatory(anal.getRegulatoryContent())
                    comm.gLogger.info(sentence)
                    comm.gLogger.info(dangerous)
                    column += 1
                    ws.Cells(row, column).Value = '\n'.join(lines)
                    column += 1
                    ws.Cells(row, column).Value = sentence
                    column += 1
                    ws.Cells(row, column).Value = dangerous

                result = CONST.RESULT_SUCCESS
            except Exception as e:
                comm.gLogger.error(e)
            finally:
                column = CONST.COLUMNS.index('분석결과') + 1
                ws.Cells(row, column).Value = result
                row += 1

    except Exception as e:
        comm.gLogger.error(e)
        comm.gLogger.exception()
        sys.exit(1)
    finally:
        if conf.log_level > CONST.LOG_LEVEL_DEBUG:
            wb.Save()
            xl.Quit()

def help():
    usage = '%s -c <company> -f <file> -d <directory>' % os.path.basename(__file__)
    comm.gLogger.info(usage)

def main(args):
    company = None
    file = None
    directory = None

    try:
        opts, args = getopt.getopt(args, 'hc:f:d:', ['help', 'company=', 'file=', 'directory='])
    except getopt.GetoptError as e:
        comm.gLogger.warning(e)
        help()
        sys.exit(2)

    for opt, arg in opts:
        if opt in ['-h', '--help']:
            help()
        elif opt in ['-c', '--company']:
            company = arg
        elif opt in ['-f', '--file']:
            file = arg
        elif opt in ['-d', '--directory']:
            directory = arg

    if directory:
        files = getFiles(directory)
        analysis(True, company, files)
    elif company and file:
        files = [file]
        analysis(False, company, files)
    else:
        help()

if __name__ == '__main__':
    main(sys.argv[1:])
