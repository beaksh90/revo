import logging, logging.handlers

import CONSTANTS as CONST
import config as conf

# Log
gLogger = logging.getLogger(__name__)
gLogger.setLevel(conf.log_level)
formatter = logging.Formatter('[%(asctime)s][%(levelname)s|%(filename)s:%(lineno)s] >> %(message)s')
fileHandler = logging.handlers.TimedRotatingFileHandler(filename=conf.path_log, when='midnight', interval=1)
fileHandler.suffix = '%Y%m%d'
fileHandler.setFormatter(formatter)
gLogger.addHandler(fileHandler)

if conf.rel_mode == CONST.REL_MODE_DEV:
    streamHandler = logging.StreamHandler()
    streamHandler.setFormatter(formatter)
    gLogger.addHandler(streamHandler)