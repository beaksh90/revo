import os, sys
import win32com.client

def openApplication(application, visible=False):
    app = None

    try:
        app = win32com.client.GetActiveObject('%s.Application' % application)
        # app = win32com.client.Dispatch('%s.Application' % application)
        if not app:
            app = win32com.client.gencache.EnsureDispatch('%s.Application' % application)
        
        if visible:
            app.Visible = visible
    except Exception as e:
        app = win32com.client.gencache.EnsureDispatch('%s.Application' % application)
        
        if visible:
            app.Visible = visible

        if not app:
            raise e

    return app

def createWorkbook(filename, visible=False):
    xl = None
    wb = None

    try:
        if os.path.isfile(filename):
            raise Exception('[Error] Existed File: %s' % filename)

        xl = openApplication('Excel', visible)

        wb = xl.Workbooks.Add()
        wb.SaveAs(filename)

    except Exception as e:
        raise e

    return xl, wb

def openWorkbook(filename, sheetname=None, create=False, visible=False):
    xl = None
    wb = None
    ws = None

    try:
        xl = openApplication('Excel', visible)

        if os.path.isfile(filename):

            basename = os.path.basename(filename)

            for workbook in xl.Workbooks:
                if workbook.Name == basename:
                    wb = workbook
                    # wb.Save()
                    break

            if not wb:
                wb = xl.Workbooks.Open(filename)

            ws = wb.ActiveSheet

            if sheetname:
                ws = None
                for worksheet in wb.Worksheets:
                    if worksheet.Name == sheetname:
                        ws = wb.Worksheets(sheetname)

                if not ws:
                    print(wb.Sheets.Count)
                    ws = wb.Worksheets.Add(After=wb.Sheets(wb.Sheets.Count))
                    ws.Name = sheetname

            wb.Activate()
            ws.Select()
        else:
            if create:
                wb = xl.Workbooks.Add()
                ws = wb.ActiveSheet

                if sheetname:
                    ws.Name = sheetname

                wb.SaveAs(filename)
                wb.Activate()
                ws.Select()

    except Exception as e:
        raise e

    return xl, wb, ws

def getCounts(ws, row, column):
    lastrow = None
    lastcol = None

    try:
        xlUp = win32com.client.constants.xlUp
        xlToLeft = win32com.client.constants.xlToLeft
        lastrow = ws.Cells(ws.Rows.Count, column).End(xlUp).Row
        lastcol = ws.Cells(row, ws.Columns.Count).End(xlToLeft).Column
    except Exception as e:
        gLogger.error(e)

    return lastrow, lastcol

def getColumnName(ws, columnIndex):
    name = None

    try:
        name = ws.Cells(1, columnIndex).Address.split('$')[1]
    except Exception as e:
        gLogger.error(e)

    return name