import re

import CONSTANTS as CONST
from .analysis_common import Analysis as Anal

class Analysis(Anal):

    def __init__(self, columns):
        Anal.__init__(self, columns)

        self.contentKO[self.contentIndexes[CONST.CONTENT_HAZARDS]]['Tokens'].extend(['2 위험 유해성', '2 유해성'])
        self.contentKO[self.contentIndexes[CONST.CONTENT_ETC]]['Tokens'].extend(['16 기타 참고사항'])

    def matchRevisionDate(self, lines):
        try:
            sentence = None
            date = None
            # lines = contents['0.제목']

            checkLineCnt = 2
            dateToken = None

            for line in lines:
                checkDate = False
                
                if sentence and checkLineCnt > 0:
                    checkDate = True
                    checkLineCnt -= 1
                else:
                    for sentenceToken in self.REVISIONDATESENTENCES:
                        if sentenceToken.upper() in line.upper():
                            checkDate = True
                            checkLineCnt -= 1

                            dateToken = sentenceToken

                            if not sentence:
                                sentence = line
                                break

                if checkDate:
                    line = line.replace(' ', '').upper()
                    index = line.find(dateToken.replace(' ', '').upper())

                    m = re.search(r'(\d{4}[년.\-/]\d{1,2}[월.\-/]\d{1,2}[일]?)|(\d{1,2}[.\-/]\d{1,2}[.\-/]\d{4})', line[index + len(dateToken.replace(' ', '')):])
                    
                    if m:
                        splitToken = None
                        if len(m.group().split('.')) == 3:
                            splitToken = 'dot'
                        elif len(m.group().split('/')) == 3:
                            splitToken = 'slash'
                        elif len(m.group().split('-')) == 3:
                            splitToken = 'dash'

                        d = re.sub(r'[년월.-]', '/', m.group())
                        d = re.sub(r'[일]', '', d)
                        dateTokens = d.split('/')

                        if len(dateTokens) == 3:
                            if len(dateTokens[2]) == 4:
                                if splitToken == 'dot' or splitToken == 'dash':
                                    # 일.월.년
                                    dateTokens = list(reversed(dateTokens))
                                elif splitToken == 'slash':
                                    # 월/일/년
                                    year = dateTokens.pop()
                                    dateTokens.insert(0, year)

                                # if self.REVERSEDREVISIONDATEFORMAT == CONST.DATE_FORMAT_USA:
                                #     year = dateTokens.pop()
                                #     dateTokens.insert(0, year)
                                # else:
                                #     dateTokens = list(reversed(dateTokens))

                            date = '-'.join(dateTokens)
                            break

                if date:
                    break

        except Exception as e:
            raise e
        finally:
            pass

        return date, sentence, lines