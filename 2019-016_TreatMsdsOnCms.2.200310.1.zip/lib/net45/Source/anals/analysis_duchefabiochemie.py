import re

import CONSTANTS as CONST
from .analysis_common import Analysis as Anal

class Analysis(Anal):

    def __init__(self, columns):
        Anal.__init__(self, columns)

        self.langHint = 'Product code'

        self.REVISIONDATESENTENCES.extend(['Date :'])
        self.REVERSEDREVISIONDATEFORMAT = CONST.DATE_FORMAT_GBR