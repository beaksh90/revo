import re
import CONSTANTS as CONST

class Analysis():

    def __init__(self, columns):
        self.COLUMNS = columns

        self.langHint = 'product name'

        self.contentKO = [
        {'Content': CONST.CONTENT_PRODUCT, 'Tokens': ['1 화학제품과 회사에 관한 정보']}
        , {'Content': CONST.CONTENT_HAZARDS, 'Tokens': ['2 유해성 위험성']}
        , {'Content': CONST.CONTENT_COMPOSITION, 'Tokens': ['3 구성성분의 명칭 및 함유량']}
        , {'Content': CONST.CONTENT_FIRSTAID, 'Tokens': ['4 응급조치 요령']}
        , {'Content': CONST.CONTENT_FIREFIGHTING, 'Tokens': ['5 폭발 화재시 대처방법']}
        , {'Content': CONST.CONTENT_RELEASE, 'Tokens': ['6 누출 사고시 대처방법']}
        , {'Content': CONST.CONTENT_HANDLING, 'Tokens': ['7 취급 및 저장방법']}
        , {'Content': CONST.CONTENT_EXPOSURE, 'Tokens': ['8 노출방지 및 개인보호구']}
        , {'Content': CONST.CONTENT_PROPERTY, 'Tokens': ['9 물리 화학적 특성']}
        , {'Content': CONST.CONTENT_STABILITY, 'Tokens': ['10 안정성 및 반응성']}
        , {'Content': CONST.CONTENT_TOXICOLOGICAL, 'Tokens': ['11 독성에 관한 정보']}
        , {'Content': CONST.CONTENT_ECOLOGICAL, 'Tokens': ['12 환경에 미치는 영향']}
        , {'Content': CONST.CONTENT_DISPOSAL, 'Tokens': ['13 폐기시 주의 사항']}
        , {'Content': CONST.CONTENT_TRANSPORT, 'Tokens': ['14 운송에 필요한 정보']}
        , {'Content': CONST.CONTENT_REGULATORY, 'Tokens': ['15 법적규제 현황']}
        , {'Content': CONST.CONTENT_ETC, 'Tokens': ['16 그밖의 참고 사항']}
        ]

        self.contentEN = [
        {'Content': CONST.CONTENT_PRODUCT, 'Tokens': ['1 PRODUCTAND COMPANY IDENTIFICATION', '1 IDENTIFICATION OF THE SUBSTANCE/MIXTURE AND OF THE COMPANY/UNDERTAKING']}
        , {'Content': CONST.CONTENT_HAZARDS, 'Tokens': ['2 HAZARDS IDENTIFICATION']}
        , {'Content': CONST.CONTENT_COMPOSITION, 'Tokens': ['3 COMPOSITION/INFORMATION ON INGREDIENTS']}
        , {'Content': CONST.CONTENT_FIRSTAID, 'Tokens': ['4 FIRST AID MEASURES']}
        , {'Content': CONST.CONTENT_FIREFIGHTING, 'Tokens': ['5 FIREFIGHTING MEASURES']}
        , {'Content': CONST.CONTENT_RELEASE, 'Tokens': ['6 ACCIDENTAL RELEASE MEASURES']}
        , {'Content': CONST.CONTENT_HANDLING, 'Tokens': ['7 HANDLING AND STORAGE']}
        , {'Content': CONST.CONTENT_EXPOSURE, 'Tokens': ['8 EXPOSURE CONTROLS/PERSONAL PROTECTION']}
        , {'Content': CONST.CONTENT_PROPERTY, 'Tokens': ['9 PHYSICAL AND CHEMICAL PROPERTIES']}
        , {'Content': CONST.CONTENT_STABILITY, 'Tokens': ['10 STABILITY AND REACTIVITY']}
        , {'Content': CONST.CONTENT_TOXICOLOGICAL, 'Tokens': ['11 TOXICOLOGICAL INFORMATION']}
        , {'Content': CONST.CONTENT_ECOLOGICAL, 'Tokens': ['12 ECOLOGICAL INFORMATION']}
        , {'Content': CONST.CONTENT_DISPOSAL, 'Tokens': ['13 DISPOSAL CONSIDERATIONS']}
        , {'Content': CONST.CONTENT_TRANSPORT, 'Tokens': ['14 TRANSPORT INFORMATION']}
        , {'Content': CONST.CONTENT_REGULATORY, 'Tokens': ['15 REGULATORY INFORMATION']}
        , {'Content': CONST.CONTENT_ETC, 'Tokens': ['16 OTHER INFORMATION']}
        ]

        self.contentIndexes = self.makeContentIndexes()

        self.REVISIONDATESENTENCES = ['개정일자', '개정날짜', 'Revision Date', 'Revision:']
        self.REVERSEDREVISIONDATEFORMAT = CONST.DATE_FORMAT_USA

        self.SIGNALSENTENCES = ['신호어', 'Signal word']
        self.SIGNALS = {
        '위험': ['위험', 'Danger']
        , '경고': ['경고', 'Warning']
        , '없음': ['없음', 'None', 'Not applicable']
        }
        self.SIGNALS_ALTER ={
            '위험': []
        , '경고': []
        , '없음': ['No known hazard'
        , '위험성 없음'
        , 'Not a hazardous'
        , '유해한 물질 또는 혼합물에 해당되지 않음'
        , 'material is not classified as hazardous'
        , '위험성 분류기준에 포함되지 않는']
        }

        self.CASSENTENCES = ['CAS 번호', '카스번호', 'CAS-No', 'CAS Number', 'CAS-번호']
        self.SUBSTANCESENTENCES = []
        self.SUBSTANCES = {
        '혼합물질': ['혼합물', 'Mixtures']
        , '단일물질': []
        # , '단일물질': ['3.1 Substances', '3 a 물질', '3 a Substances']
        # , '단일물질': ['물질', 'Substances']
        }

        self.TEMPERATURESENTENCES = ['온도', 'temperature', '°C', '°F', '℃', '◦C']
        self.HANDLINGS = {
        '일반': ['통풍', '서늘', '시원', '냉암소', '옥외', '환기', 'ventilated', 'Cool']
        ,'냉장': ['냉장', 'Cold', 'refrige', 'refrigeration']
        ,'냉동': ['냉동' ,'freeze']
        }

        self.FORMSENTENCES = ['형태', '성상', 'Appearance']
        self.FORMS = {
        '점성': ['점성', 'viscous']
        , '액체': ['액체', 'liquid']
        , '고체': ['고체', '결정체', '덩어리', '막대', '페이스트', 'solid', 'crystalline', 'tablet']
        , '기체': ['기체', '분말', 'powder']
        }

        self.DANGEROUSSENTENCES = ['위험물안전관리법에 의한 규제'
        , 'Dangerous Substances Safety Management Act']
        self.WASTESSENTENCES = ['폐기물관리법'
        , 'Wastes Control Act']

        self.contents = None

    def getRevisionDateContent(self):
        return self.contents[CONST.CONTENT_TITLE]
    def getSignalContent(self):
        return self.contents[CONST.CONTENT_HAZARDS]
    def getCASContent(self):
        return self.contents[CONST.CONTENT_COMPOSITION]
    def getHandlingContent(self):
        return self.contents[CONST.CONTENT_HANDLING]
    def getFormContent(self):
        return self.contents[CONST.CONTENT_PROPERTY]
    def getRegulatoryContent(self):
        return self.contents[CONST.CONTENT_REGULATORY]
    def getAllContent(self):
        contents = []

        for c in self.contents:
            contents += self.contents[c]

        return contents

    def makeContentIndexes(self):
        try:
            indexes = {}
            for i in range(0, len(self.contentKO)):
                c = self.contentKO[i]['Content']
                indexes[c] = i
        except Exception as e:
            raise e
        finally:
            pass

        return indexes

    def matchLanguage(self, lines):
        try:
            lang = 'KOR'

            hint = self.langHint.upper()

            for line in lines:
                if hint in line.upper():
                    lang = 'ENG'
        except Exception as e:
            raise e
        finally:
            pass

        return lang

    def matchContents(self, lines):

        try:
            matchedContents = {}
            missmatched = []
            lang = self.matchLanguage(lines)

            contents = self.contentKO

            if lang == 'ENG':
                contents = self.contentEN

            cs = list(contents)

            for i in range(0, len(contents)):
                c = contents[i]
                content = c['Content'].replace(' ', '').upper()
                missmatched.append(content)

            cnt = 1
            currentContent = CONST.CONTENT_TITLE
            matchedContents[currentContent] = []

            for line in lines:
                line = line.strip()
                if line == '':
                    continue

                # print('Line %d: %s' % (cnt, line))

                # 허용하는 문자: 한글, 영어, 숫자, 특수문자(.)
                cleanLine = ''.join(re.findall('[가-힝a-zA-Z0-9/]', line)).upper()
                
                nextContent = False

                for i in range(0, len(cs)):
                    c = cs[i]
                    content = c['Content'].replace(' ', '').upper()
                    tokens = c['Tokens']

                    for token in tokens:
                        token = token.replace(' ', '').upper()

                        if token in cleanLine and currentContent != content:
                            missmatched.remove(content)
                            nextContent = True
                            currentContent = content
                            matchedContents[currentContent] = []
                            break
                    
                    if nextContent:
                        break

                # line = re.sub(r'[-=+,#/\?:^$.@*\"※~&%ㆍ!』\\‘|\(\)\[\]\<\>`\'…》]', '', line)
                matchedContents[currentContent].append(line)

                cnt += 1

            print('-' * 30)
            if len(missmatched) == 0:
                matched = True

                self.contents = matchedContents
            else:
                # print(filepath)
                print(missmatched)
                print('미매칭 Contents:', len(missmatched))

        except Exception as e:
            raise e
        finally:
            pass

        return lang, matchedContents, missmatched

    # def matchRevisionDate(self, contents):
    #     try:
    #         sentence = None
    #         date = None
    #         lines = contents['0.제목']

    #         checkLineCnt = 2

    #         for line in lines:
    #             checkDate = False

    #             if sentence and checkLineCnt > 0:
    #                 checkDate = True
    #                 checkLineCnt -= 1
    #             else:
    #                 for sentenceToken in self.REVISIONDATESENTENCES:
    #                     if sentenceToken.upper() in line.upper():
    #                         checkDate = True
    #                         checkLineCnt -= 1
    #                         if not sentence:
    #                             sentence = line

    #             if checkDate:
    #                 m = re.search(r'(\d{4}[.\-/]\d{2}[.\-/]\d{2})|(\d{2}[.\-/]\d{2}[.\-/]\d{4})', line)
                        
    #                 if m:
    #                     splitToken = None
    #                     if len(m.group().split('.')) == 3:
    #                         splitToken = 'dot'
    #                     elif len(m.group().split('/')) == 3:
    #                         splitToken = 'slash'

    #                     d = re.sub(r'[.-]', '/', m.group())
    #                     dateTokens = d.split('/')

    #                     if len(dateTokens) == 3:
    #                         if len(dateTokens[2]) == 4:

    #                             if splitToken == 'dot':
    #                                 # 일.월.년
    #                                 dateTokens = list(reversed(dateTokens))
    #                             elif splitToken == 'slash':
    #                                 # 월/일/년
    #                                 year = dateTokens.pop()
    #                                 dateTokens.insert(0, year)

    #                         date = '-'.join(dateTokens)
    #                         break

    #             if date:
    #                 break

    #     except Exception as e:
    #         raise e
    #     finally:
    #         pass

    #     return date, sentence, lines

    def matchRevisionDate(self, lines):
        try:
            sentence = None
            date = None
            # lines = contents['0.제목']

            checkLineCnt = 2
            dateToken = None

            for line in lines:
                checkDate = False
                
                if sentence and checkLineCnt > 0:
                    checkDate = True
                    checkLineCnt -= 1
                else:
                    for sentenceToken in self.REVISIONDATESENTENCES:
                        if sentenceToken.upper() in line.upper():
                            checkDate = True
                            checkLineCnt -= 1

                            dateToken = sentenceToken

                            if not sentence:
                                sentence = line
                                break

                if checkDate:
                    line = line.replace(' ', '').upper()
                    index = line.find(dateToken.replace(' ', '').upper())

                    m = re.search(r'(\d{4}[년.\-/]\d{1,2}[월.\-/]\d{1,2}[일]?)|(\d{1,2}[.\-/]\d{1,2}[.\-/]\d{4})', line[index + len(dateToken.replace(' ', '')):])
                    
                    if m:
                        # splitToken = None
                        # if len(m.group().split('.')) == 3:
                        #     splitToken = 'dot'
                        # elif len(m.group().split('/')) == 3:
                        #     splitToken = 'slash'
                        # elif len(m.group().split('-')) == 3:
                        #     splitToken = 'dash'

                        d = re.sub(r'[년월.-]', '/', m.group())
                        d = re.sub(r'[일]', '', d)
                        dateTokens = d.split('/')

                        if len(dateTokens) == 3:
                            if len(dateTokens[2]) == 4:
                                # if splitToken == 'dot' or splitToken == 'dash':
                                #     # 일.월.년
                                #     dateTokens = list(reversed(dateTokens))
                                # elif splitToken == 'slash':
                                #     # 월/일/년
                                #     year = dateTokens.pop()
                                #     dateTokens.insert(0, year)

                                if self.REVERSEDREVISIONDATEFORMAT == CONST.DATE_FORMAT_USA:
                                    year = dateTokens.pop()
                                    dateTokens.insert(0, year)
                                else:
                                    dateTokens = list(reversed(dateTokens))

                            date = '-'.join(dateTokens)
                            break

                if date:
                    break

        except Exception as e:
            raise e
        finally:
            pass

        return date, sentence, lines

    def matchTemperature(self, lines):
        temperature = None
        handling = None

        try:
            lines = ''.join(lines)
            # regex = r'([-]?[0-9\s]+-[-]?[0-9°\s]+[Cc]|[-]?[0-9°\s]+[Cc]-[-]?[0-9°\s]+[Cc])'
            # regex = r'([-]?[0-9\s]+-\s+[-]?[0-9°\s]+[Cc]|[-]?[0-9°\s]+[Cc]-\s+[-]?[0-9°\s]+[Cc])'
            # regex = r'([-−]?[0-9]+\s*-\s*[-−]?[0-9]+\s*[°◦][Cc]|[-−]?[0-9]+\s*[°◦][Cc]\s*-\s*[-−]?[0-9]\s*[°◦]?[Cc])'
            regex = r'([-−]?[0-9]+\s*[-~]\s*[-−]?[0-9]+\s*[°◦]?[Cc℃]|[-−]?[0-9]+\s*[°◦]?[Cc℃]\s*[-~]\s*[-−]?[0-9]\s*[°◦]?[Cc℃])'
            p = re.compile(regex)
            m = p.search(lines)

            if m:
                temperature = m.group()
                # print('temperature:', temperature)
                # cleanTemperature = temperature.replace(' ', '').replace('°C', '').replace('°c', '')
                cleanTemperature = re.sub(r'[\s°◦Cc]', '', temperature)
                # print('cleanTemperature:', cleanTemperature)
                result = [int(d) for d in re.findall(r'-?\d+', temperature)]
                
                minT = None
                maxT = None

                if len(result) == 2:
                    minT = result[0]
                    maxT = result[1]

                    if 0 <= minT and maxT <= 15:
                        handling = '냉장'
                    elif minT < 0:
                        handling = '냉동'
                    elif minT > 15:
                        handling = '일반'

                return temperature, handling

            # regex = r'([-−]?[0-9°\s]+[Cc])'
            regex = r'([-−]?[0-9]+\s*[°◦]?[Cc℃])'
            p = re.compile(regex)
            m = p.search(lines)

            if m:
                temperature = m.group()
                print('temperature:', temperature)
                result = [int(re.sub(r'[−]', '-', d)) for d in re.findall(r'[-−]?\d+', temperature)]
                print('result:', result)
                
                minT = None

                if len(result) == 1:
                    minT = result[0]

                    if 0 <= minT and minT <= 15:
                        handling = '냉장'
                    elif minT < 0:
                        handling = '냉동'
                    elif minT > 15:
                        handling = '일반'
                        
                return temperature, handling

        except Exception as e:
            raise e
        finally:
            pass

        return temperature, handling

    def matchSignal(self, lines):
        try:
            sentence = None
            signal = None
            # lines = contents['2.유해성위험성']

            signalSentence = None

            checkLineCnt = 2

            for line in lines:

                for sentenceToken in self.SIGNALSENTENCES:

                    if sentenceToken.upper() in line.upper():
                        sentence = line
                        index = line.find(sentenceToken)
                        # print(line[index + len(sentenceToken):])
                        signalSentence = line[index + len(sentenceToken):].strip()
                
                if sentence and checkLineCnt > 0:
                    signalSentence = line

                if signalSentence:
                    checkLineCnt -= 1
                    for token in self.SIGNALS:
                        ts = self.SIGNALS[token]
                        for t in ts:
                            if t.upper() in signalSentence.upper():
                                signal = token
                                break
                        if signal:
                            break
                if signal:
                    break

            if not signal and len(self.SIGNALS_ALTER) > 0:
                allLine = ''.join(lines)

                for token in self.SIGNALS_ALTER:
                    ts = self.SIGNALS_ALTER[token]

                    for t in ts:
                        if t.replace(' ', '').upper() in allLine.replace(' ', '').upper():
                            signal = token
                            sentence = 'ALTER'
                            break
                    if signal:
                        break

        except Exception as e:
            raise e
        finally:
            # if signalSentence == None:
            #     signal = '없음'
            pass

        return signal, sentence, lines

    def matchSubstance(self, lines, casInfos):
        try:
            sentence = None
            composition = None
            regression = None

            detected = False

            for line in lines:

                substanceSentence = None

                for sentenceToken in self.SUBSTANCESENTENCES:
                    if sentenceToken.upper() in line.upper():
                        detected = True
                        sentence = line
                        index = line.find(sentenceToken)
                        substanceSentence = line[index + len(sentenceToken):].replace(':', '').strip()
                        break

                if len(self.SUBSTANCESENTENCES) == 0:
                    detected = True
                    substanceSentence = line

                if detected:
                    for token in self.SUBSTANCES:
                        ts = self.SUBSTANCES[token]

                        for t in ts:
                            if t.upper().replace(' ', '') in substanceSentence.upper().replace(' ', ''):
                                sentence = line
                                composition = token
                                break

                        if composition:
                            break
                
                if composition:
                    break

            # if composition == '단일물질' and len(casInfos) == 1:
            #     regression = '일치'
            # elif composition == '혼합물질' and len(casInfos) > 1:
            #     regression = '일치'
            if not composition and len(casInfos) == 1:
                composition = '단일물질'
                regression = '일치'
                sentence = '단일물질 문구 없음, CAS 번호 수: %d' % len(casInfos)
            elif not composition and len(casInfos) > 1:
                composition = '혼합물질'
                regression = '일치'
                sentence = '혼합물질 문구 없음, CAS 번호 수: %d' % len(casInfos)

        except Exception as e:
            raise e
        finally:
            pass

        return composition, regression, sentence, lines

    def matchCAS(self, lines):
        try:
            casNos = []
            casInfos = []

            detected = False
            casNo = None
            concentration = None

            for line in lines:
                
                # for sentenceToken in self.CASSENTENCES:

                #     if sentenceToken.upper() in line.upper():
                #         detected = True
                #         casNo = None
                #         concentration = None

                # m = re.search(r'\d+-\d+-\d{1}(?!\d)', line)
                m = re.search(r'\d+-\d{2}-\d{1}(?!\d)', line)
                # m = re.search(r'\s*\d+-\d+-\d{1}(?!\d)', line)
                
                # if detected and m:
                if m:
                    detected = False

                    ms = m.start()
                    if ms > 0:
                        prevStr = line[ms - 1]
                        if prevStr != ' ':
                            continue

                    no = m.group().strip()
                    
                    # CAS NO 판별 로직 구현 필요 ( EC번호와 CAS 번호 구별시 필요 ) 
                    # For example, the CAS number of water is 7732-18-5: 
                    # the checksum 5 is calculated as 
                    # (8×1 + 1×2 + 2×3 + 3×4 + 7×5 + 7×6) = 105; 105 mod 10 = 5.

                    nums = list(no.replace('-', ''))
                    mod = int(nums.pop())
                    nums.reverse()
                    result = 0
                    for i in range(0, len(nums)):
                        num = int(nums[i])
                        result += num * (i + 1)

                    if result%10 == mod:
                        casNo = no
                        if not casNo in casNos:
                            casNos.append(casNo)
                            casInfo = '%s|||' % (casNo)
                            casInfos.append(casInfo)

                if casNo:
                    m = re.search(r'(>=*\s\d+(\s\%)?\s-\s)?<=*\s\d+\s%', line)
                    if m:
                        concentration = m.group()
                        index = -1
                        if ('%s|||' % casNo) in casInfos:
                            index = casInfos.index('%s|||' % casNo)

                        if index >= 0:
                            casInfo = '%s|%s|%s|%s' % (casNo, concentration, '', '')
                            casInfos[index] = casInfo
                        
                        casNo = None
                        concentration = None
                        continue

                    m = re.search(r'(\d*\.?\d*~)?\d+\.?\d*\s*%', line)
                    if m:
                        concentration = m.group()
                        index = -1
                        if ('%s|||' % casNo) in casInfos:
                            index = casInfos.index('%s|||' % casNo)

                        if index >= 0:
                            casInfo = '%s|%s|%s|%s' % (casNo, concentration, '', '')
                            casInfos[index] = casInfo
                        
                        casNo = None
                        concentration = None
                        continue

        except Exception as e:
            raise e
        finally:
            pass

        return casInfos, lines

    def matchHandling(self, lines):
        try:
            # -일반조건 : 통풍이 잘되는, 서늘한, 시원한, Cool, 냉암소
            # -냉장조건 : 냉장고, 냉장, 0< <15도 사이의 온도 범위, Cold, refrige, refrigeration 
            # -냉동조건 : 냉동고, 냉동, 0도 이하의 온도, freeze
            handling = None
            temperatureLine = []
            temperature = None
            # lines = contents['7.취급및저장방법']

            for line in lines:
                # p = re.compile('[-]?[0-9]?[0-9]°C')
                # m = p.match(line)
                # m = re.findall(r'\d+°[Cc]?(-\d+°[Cc])?', line.replace(' ', ''))

                # temperature = '\n'.join(m)

                for sentenceToken in self.TEMPERATURESENTENCES:

                    if sentenceToken.upper() in line.upper():
                        temperatureLine.append(line)
                        break

                for token in self.HANDLINGS:
                    
                    ts = self.HANDLINGS[token]

                    for t in ts:
                        if t.upper() in line.upper():
                            handling = token
                            temperature = t
                            break

                    if handling:
                        break

        except Exception as e:
            raise e
        finally:
            pass

        tempTemperature, tempHandling = self.matchTemperature(temperatureLine)
        # tempTemperature, tempHandling = self.matchTemperature(''.join(lines))

        if tempHandling:
            handling = tempHandling
            temperature = tempTemperature

        return handling, temperatureLine, temperature, lines

    def matchCodes(self, lines):
        try:
            hcodes = []
            pcodes = []
            lines = '\n'.join(lines)

            # cs = re.findall(r'(H[0-9]{3}\s*\+\s*H[0-9]{3})|(H[0-9]{3})', lines)
            # cs = re.findall(r'[\+]?\s*H[0-9]{3}', lines)
            cs = re.findall(r'[\+]?\s*H[2-4][0-9]{2}', lines)
            # cs = re.findall(r'H[0-9]{3}(\s*[+]\s*H[0-9]{3})*', lines)
            for c in cs:
                c = c.replace(' ', '').strip()

                if c[0] == '+':
                    prevCode = hcodes.pop()
                    # mCode = prevCode + c
                    mCode = prevCode + ' + ' + c[1:]

                    if not mCode in hcodes:
                        hcodes.append(mCode)
                else:
                    if not c in hcodes:
                        hcodes.append(c)

            # cs = re.findall(r'[\+]?\s*P[0-9]{3}', lines)
            cs = re.findall(r'[\+]?\s*P[2-5][0-9]{2}', lines)
            for c in cs:
                c = c.replace(' ', '').strip()

                if c[0] == '+':
                    prevCode = pcodes.pop()
                    # mCode = prevCode + c
                    mCode = prevCode + ' + ' + c[1:]

                    if not mCode in pcodes:
                        pcodes.append(mCode)
                else:
                    if not c in pcodes:
                        pcodes.append(c)

            if len(pcodes) == 0:
                pcodes = CONST.PCODE_DEFAULT

        except Exception as e:
            raise e
        finally:
            pass

        return hcodes, pcodes

    def matchPictogram(self, hcodes, data):
        try:
            pictograms = []
            regression = []

            for hcode in hcodes:
                hcode = hcode.split('+')[0].strip()
                
                if hcode in data:
                    ghcodes = list(data[hcode])
                    pictograms = list(sorted(set().union(pictograms, ghcodes)))
                else:
                    if not hcode in regression:
                        regression.append(hcode)

        except Exception as e:
            raise e
        finally:
            pass

        return pictograms, regression

    def matchForm(self, lines):
        try:
            sentence = None
            form = None
            # lines = contents['9.물리화학적특성']

            checkLineCnt = 2

            for line in lines:

                formSentence = None

                for sentenceToken in self.FORMSENTENCES:
                    if sentenceToken.upper() in line.upper():
                        sentence = line
                        index = line.find(sentenceToken)
                        # print(line[index + len(sentenceToken):])
                        formSentence = line[index + len(sentenceToken):].replace(':', '').strip()
                        break

                if sentence and checkLineCnt > 0:
                    formSentence = line

                if formSentence:
                    checkLineCnt -= 1
                    formSentenceTokens = formSentence.split(',')
                    for formSentenceToken in formSentenceTokens:
                        for token in self.FORMS:
                            ts = self.FORMS[token]
                            for t in ts:
                                if t.upper() in formSentenceToken.upper():
                                    form = token
                                    break
                            if form:
                                break
                        if form:
                                break
                if form:
                    break

        except Exception as e:
            raise e
        finally:
            pass

        return form, sentence, lines

    def matchRegulatory(self, lines):
        try:
            sentence = None
            continueLine = None
            dangerous = None

            for line in lines:
                if continueLine == False:
                    break

                elif continueLine == True:
                    for sentenceToken in self.WASTESSENTENCES:
                        if sentenceToken.upper() in line.upper():
                            continueLine = False
                            break

                    if continueLine == True:
                        dangerous += '\n%s' % line
                elif continueLine == None:
                    for sentenceToken in self.DANGEROUSSENTENCES:
                        if sentenceToken.upper() in line.upper():
                            sentence = line
                            index = line.find(sentenceToken)
                            dangerous = line[index + len(sentenceToken):].replace(':', '').strip()
                            continueLine = True
                            break

        except Exception as e:
            raise e
        finally:
            pass

        return dangerous, sentence, lines