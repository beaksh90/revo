import re

import CONSTANTS as CONST
from .analysis_common import Analysis as Anal

class Analysis(Anal):

    def __init__(self, columns):
        Anal.__init__(self, columns)

        self.contentEN[self.contentIndexes[CONST.CONTENT_PRODUCT]]['Tokens'].extend(['1 Identification of the substance', '1 Identi'])
        self.contentEN[self.contentIndexes[CONST.CONTENT_HAZARDS]]['Tokens'].extend(['2 Hazards'])
        self.contentEN[self.contentIndexes[CONST.CONTENT_FIREFIGHTING]]['Tokens'].extend(['5 Fire'])
        self.contentEN[self.contentIndexes[CONST.CONTENT_DISPOSAL]]['Tokens'].extend(['13 DISPOSAL CONSIDERATION'])
        self.contentEN[self.contentIndexes[CONST.CONTENT_TRANSPORT]]['Tokens'].extend(['14 Transportation information'])

        self.SIGNALSENTENCES.extend(['Single word'])
        # self.CASSENTENCES.extend(['CAS number'])

        self.TEMPERATURESENTENCES.extend(['◦C'])
        self.HANDLINGS['일반'].extend(['Storage: Store in closed vessels.'])

    def getCASContent(self):
        return self.contents[CONST.CONTENT_PRODUCT] + self.contents[CONST.CONTENT_COMPOSITION]

    def matchRevisionDate(self, lines):
        try:
            sentence = None
            date = None
            # lines = contents['0.제목']

            ### 첫페이지 상단에 개정일자 존재
            for line in lines:
                # m = re.search(r'(\d{4}[.\-/]\d{2}[.\-/]\d{2})|(\d{2}[.\-/]\d{2}[.\-/]\d{4})', line)
                line = line.replace(' ', '')
                m = re.search(r'(\d{4}[년.\-/]\d{1,2}[월.\-/]\d{1,2}[일]?)|(\d{1,2}[.\-/]\d{1,2}[.\-/]\d{4})', line)
                
                if m:
                    sentence = line
                    splitToken = None
                    if len(m.group().split('.')) == 3:
                        splitToken = 'dot'
                    elif len(m.group().split('/')) == 3:
                        splitToken = 'slash'

                    # d = re.sub(r'[.-]', '/', m.group())
                    d = re.sub(r'[년월.-]', '/', m.group())
                    d = re.sub(r'[일]', '', d)
                    dateTokens = d.split('/')

                    if len(dateTokens) == 3:
                        if len(dateTokens[2]) == 4:

                            if splitToken == 'dot':
                                # 일.월.년
                                dateTokens = list(reversed(dateTokens))
                            elif splitToken == 'slash':
                                # 월/일/년
                                year = dateTokens.pop()
                                dateTokens.insert(0, year)

                        date = '-'.join(dateTokens)
                        break

                if date:
                    break
            ### 첫페이지 상단에 개정일자 존재

        except Exception as e:
            raise e
        finally:
            pass

        return date, sentence, lines