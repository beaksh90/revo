import re

import CONSTANTS as CONST
from .analysis_common import Analysis as Anal

class Analysis(Anal):

    def __init__(self, columns):
        Anal.__init__(self, columns)

        self.contentKO[self.contentIndexes[CONST.CONTENT_HAZARDS]]['Tokens'].extend(['2 유해 위험성'])
        self.contentKO[self.contentIndexes[CONST.CONTENT_REGULATORY]]['Tokens'].extend(['15 일본 법적규제 정보'])
        self.contentKO[self.contentIndexes[CONST.CONTENT_ETC]]['Tokens'].extend(['16 기타 정보'])

        self.contentEN[self.contentIndexes[CONST.CONTENT_PRODUCT]]['Tokens'].extend(['1 IDENTIFICATION'])
        self.contentEN[self.contentIndexes[CONST.CONTENT_REGULATORY]]['Tokens'].extend(['15 JAPANESE REGULATORY INFORMATION'])

        self.CASSENTENCES.extend(['CAS RN'])
        self.SUBSTANCESENTENCES.extend(['물질/혼합물', 'Substance/mixture'])
        self.SUBSTANCES['단일물질'].extend(['물질', 'Substance'])

        self.FORMSENTENCES.extend(['물리적 상태', 'Physical state'])

    def getSignalContent(self):
        ### Text 문서에 CAS 정보가 각 장들에 산재되어 있어, 전체에서 조회하도록 함
        return self.getAllContent()
        ###

    def getCASContent(self):
        ### Text 문서에 CAS 정보가 각 장들에 산재되어 있어, 전체에서 조회하도록 함
        return self.getAllContent()
        ###