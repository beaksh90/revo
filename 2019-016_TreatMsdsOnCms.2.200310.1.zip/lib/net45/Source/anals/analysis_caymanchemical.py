import re

import CONSTANTS as CONST
from .analysis_common import Analysis as Anal

class Analysis(Anal):

    def __init__(self, columns):
        Anal.__init__(self, columns)

        self.CASSENTENCES.extend(['GHS Classification', 'RTECS'])