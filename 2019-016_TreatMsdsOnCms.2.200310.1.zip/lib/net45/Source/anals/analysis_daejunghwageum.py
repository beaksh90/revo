import re

import CONSTANTS as CONST
from .analysis_common import Analysis as Anal

class Analysis(Anal):

    def __init__(self, columns):
        Anal.__init__(self, columns)

        self.contentKO[self.contentIndexes[CONST.CONTENT_PROPERTY]]['Tokens'].extend(['9 물리화학적 특정 '])
        
        # self.contentEN[self.contentIndexes[CONST.CONTENT_PRODUCT]]['Tokens'].extend(['1 Identification of the substance/mixture and of the company/undertaking'])

        self.REVISIONDATESENTENCES = ['최종 개정일자:']

    def getRevisionDateContent(self):
        return self.contents[CONST.CONTENT_ETC]