import os
import CONSTANTS as CONST

# Release Mode
rel_mode = CONST.REL_MODE_DEV

# 경로
path_data = 'C:\\RPA_Repository\\2019-016_TreatMsdsOnCms'
path_home = os.path.dirname(os.path.realpath(__file__))
path_analysis = os.path.join(path_home, 'analysis.xlsx')
path_master = os.path.join(path_home, 'master.xlsx')

# Log
log_level = CONST.LOG_LEVEL_WARNING
path_log = os.path.join(path_data, 'Log', 'msdn.log')

# 그림문자
sheet_name_pictogram = '그림문자'