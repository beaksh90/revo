# Release Mode
REL_MODE_DEV = 'DEV'
REL_MODE_PRD = 'PRD'

# Log
LOG_LEVEL_DEBUG = 10
LOG_LEVEL_INFO = 20
LOG_LEVEL_WARNING = 30
LOG_LEVEL_ERROR = 40
LOG_LEVEL_CIRITCAL = 50

# 내용
CONTENT_TITLE = '제목'
CONTENT_PRODUCT = '화학제품과회사에관한정보'
CONTENT_HAZARDS = '유해성위험성'
CONTENT_COMPOSITION = '구성성분의명칭및함유량'
CONTENT_FIRSTAID = '응급조치요령'
CONTENT_FIREFIGHTING = '폭발화재시대처방법'
CONTENT_RELEASE = '누출사고시대처방법'
CONTENT_HANDLING = '취급및저장방법'
CONTENT_EXPOSURE = '노출방지및개인보호구'
CONTENT_PROPERTY = '물리화학적특성'
CONTENT_STABILITY = '안정성및반응성'
CONTENT_TOXICOLOGICAL = '독성에관한정보'
CONTENT_ECOLOGICAL = '환경에미치는영향'
CONTENT_DISPOSAL = '폐기시주의사항'
CONTENT_TRANSPORT = '운송에필요한정보'
CONTENT_REGULATORY = '법적규제현황'
CONTENT_ETC = '그밖의참고사항'

# 분석결과
RESULT_SUCCESS = '성공'
RESULT_FAIL = '실패'

# 엑셀
COLOR_RGB_EXCEL_GREEN = (146, 208, 80)
COLOR_RGB_EXCEL_LIGHTGRAY = (242, 242, 242)
COLOR_INDEX_EXCEL_RED = 3
COLOR_INDEX_EXCEL_ORANGE = 44

COLUMNS = [
'파일'
, '언어'
, '문서양식'
, '분석불가항목'
, '0.제목'
, '개정일자문구'
, '개정일자'
, '2.유해성위험성'
, '신호어문구'
, '신호어'
, 'H코드'
, 'P코드'
, '그림문자'
, '그림문자불일치'
, '3.구성성분의명칭및함유량'
, 'CAS번호'
, '타입문구'
, '타입'
, '타입일치'
, '7.취급및저장방법'
, '온도문구'
, '저장식별'
, '저장방법'
, '9.물리화학적특정'
, '형태문구'
, '형태'
, '15.법적규제현황'
, '규제문구'
, '규제'
, '분석결과'
]

MARKINGS = [
'개정일자'
, '신호어'
, 'H코드'
, 'P코드'
, '그림문자'
, '타입'
, 'CAS번호'
, '저장방법'
, '형태'
, '규제'
]

# Default P코드
PCODE_DEFAULT = [
'P103'
, 'P201'
, 'P501'
]

# 날짜 형식
DATE_FORMAT_GBR = '일/월/년'
DATE_FORMAT_USA = '월/일/년'
DATE_FORMAT_KOR = '년/월/일'

# 회사명
COMPANY_NAMES_SIGMAALDRICH = ['SIGMA-ALDRICH', 'sigmaaldrich']
COMPANY_NAMES_COMBIBLOCKS = ['CombiBlocksInc', 'Combi-Blocks']
COMPANY_NAMES_DAEJUNGHWAGEUM = ['대정화금']
COMPANY_NAMES_TCI = ['TCITokyoChemicalIndustrycoLtd', 'TOKYOCHEMICALINDUSTRYCOLTD']
COMPANY_NAMES_ALFAAESAR = ['ALFAAESAR']
COMPANY_NAMES_CAYMANCHEMICAL = ['CaymanChemical']
COMPANY_NAMES_DUCHEFABIOCHEMIE = ['DuchefaBiochemie']